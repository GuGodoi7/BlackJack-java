package com.example;

public class Computador extends Jogador {
    
    @Override
    public Boolean parou() {
        return this.getPontos() > 16;
    }

}
