package com.example;

public enum Naipe {
    Clubs,
    Diamonds,
    Hearts,
    Spades
}
